open Simulator
open Strategy
open Command

;;

(* let controller _ = nop *)
(*   (\* revive_any_dead  *\) *)
(*   (\*   (fun _ -> *\) *)
(*        (\* heal_damaged2 *\) *)
(*        (\* 	 (fun _ -> *\) *)
(*        (\* 	    protect_against_attack *\) *)
(*        (\* 	      (fun _ -> *\) *)
(*        (\* 		 zombienize *\) *)
(*        (\* 		   (fun _ -> normal_attack nop))) *\) in *)
(* run_simulator controller *)

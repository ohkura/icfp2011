exception Error

type field_type =
  | Identity
  | Succ
  | Dbl
  | Get
  | Put | PutX
  | S | Sf of field_type | Sfg of field_type * field_type
  | K | KX of field_type
  | Inc
  | Dec
  | Attack | AttackI of field_type | AttackIJ of field_type * field_type
  | Help | HelpI of field_type | HelpIJ of field_type * field_type
  | Copy
  | Revive
  | Zombie | ZombieI of field_type
  | Value of int

let proponent = Array.init 256 (fun _ -> (Identity, 10000))
let opponent = Array.init 256 (fun _ -> (Identity, 10000))

let validate_number i =
  match i with
    | Value(x) -> x
    | _ -> raise Error

let validate_slot i =
  match i with
    | Value(x) ->
      if x >= 0 && x < 256 then
	x
      else
	raise Error
    | _ -> raise Error

let max a b =
  if a > b then a else b
let min a b =
  if a > b then b else a

let succ n =
  let x = validate_number n in
  if x < 65535 then
    Value(x + 1)
  else
    Value(65535)
let dbl n =
  let x = validate_number n in
  if x < 32768 then
    Value(x * 2)
  else
    Value(65535)
let prop_get i =
  let x = validate_slot i in
  let field, vitality = Array.get proponent x in
  if vitality > 0 then
    field
  else
    raise Error
let opp_get i =
  let x = validate_slot i in
  let field, vitality = Array.get opponent x in
  if vitality > 0 then
    field
  else
    raise Error
let prop_inc i =
  let x = validate_slot i in
  let field, vitality = Array.get proponent x in
  let _ =
    if vitality > 0 && vitality < 65535 then
      Array.set proponent x (field, vitality + 1)
    else
      () in
  Identity
let opp_inc i =
  let x = validate_slot i in
  let field, vitality = Array.get opponent x in
  let _ =
    if vitality > 0 && vitality < 65535 then
      Array.set opponent x (field, vitality + 1)
    else
      () in
  Identity
let prop_dec i =
  let x = validate_slot i in
  let field, vitality = Array.get opponent (255 - x) in
  let _ =
    if vitality > 0 then
      Array.set opponent (255 - x) (field, vitality - 1)
    else
      () in
  Identity
let opp_dec i =
  let x = validate_slot i in
  let field, vitality = Array.get proponent (255 - x) in
  let _ =
    if vitality > 0 then
      Array.set proponent (255 - x) (field, vitality - 1)
    else
      () in
  Identity
let prop_attack i j n =
  let x = validate_slot i in
  let amount = validate_number n in
  let prop_field, prop_vitality = Array.get proponent x in
  let _ =
    if prop_vitality < amount then
      raise Error
    else
      Array.set proponent x (prop_field, prop_vitality - amount) in
  let y = validate_slot j in
  let opp_field, opp_vitality = Array.get opponent (255 - y) in
  let _ =
    Array.set opponent (255 - y) (opp_field, max (opp_vitality - amount * 9 / 10) 0) in
  Identity
let opp_attack i j n =
  let x = validate_slot i in
  let amount = validate_number n in
  let opp_field, opp_vitality = Array.get opponent x in
  let _ =
    if opp_vitality < amount then
      raise Error
    else
      Array.set opponent x (opp_field, opp_vitality - amount) in
  let y = validate_slot j in
  let prop_field, prop_vitality = Array.get proponent (255 - y) in
  let _ =
    Array.set proponent (255 - y) (prop_field, max (prop_vitality - amount * 9 / 10) 0) in
  Identity
let prop_help i j n =
  let x = validate_slot i in
  let amount = validate_number n in
  let prop_field, prop_vitality = Array.get proponent x in
  let _ =
    if prop_vitality < amount then
      raise Error
    else
      Array.set proponent x (prop_field, prop_vitality - amount) in
  let y = validate_slot j in
  let prop_field, prop_vitality = Array.get proponent y in
  let _ =
    if prop_vitality <= 0 then
      ()
    else
      Array.set proponent y (prop_field, min (prop_vitality + amount * 11 / 10) 65535) in
  Identity
let opp_help i j n =
  let x = validate_slot i in
  let amount = validate_number n in
  let opp_field, opp_vitality = Array.get opponent x in
  let _ =
    if opp_vitality < amount then
      raise Error
    else
      Array.set opponent x (opp_field, opp_vitality - amount) in
  let y = validate_slot j in
  let opp_field, opp_vitality = Array.get opponent y in
  let _ =
    if opp_vitality <= 0 then
      ()
    else
      Array.set opponent y (opp_field, min (opp_vitality + amount * 11 / 10) 65535) in
  Identity
let prop_copy i =
  let x = validate_slot i in
  let field, _ = Array.get opponent x in
  field
let opp_copy i =
  let x = validate_slot i in
  let field, _ = Array.get proponent x in
  field
let prop_revive i =
  let x = validate_slot i in
  let field, vitality = Array.get proponent x in
  let _ =
    if vitality <= 0 then
      Array.set proponent x (field, 1)
    else
      () in
  Identity
let opp_revive i =
  let x = validate_slot i in
  let field, vitality = Array.get opponent x in
  let _ =
    if vitality <= 0 then
      Array.set opponent x (field, 1)
    else
      () in
  Identity
let prop_zombie i x =
  let slot = validate_slot i in
  let field, vitality = Array.get opponent (255 - slot) in
  if vitality <= 0 then
    let _ = Array.set opponent (255 - slot) (x, -1) in
    Identity
  else
    raise Error
let opp_zombie i x =
  let slot = validate_slot i in
  let field, vitality = Array.get proponent (255 - slot) in
  if vitality <= 0 then
    let _ = Array.set proponent (255 - slot) (x, -1) in
    Identity
  else
    raise Error

let parse_card card =
  match card with
    | "I" -> Identity
    | "zero" -> Value(0)
    | "succ" -> Succ
    | "dbl" -> Dbl
    | "get" -> Get
    | "put" -> Put
    | "S" -> S
    | "K" -> K
    | "inc" -> Inc
    | "dec" -> Dec
    | "attack" -> Attack
    | "help" -> Help
    | "copy" -> Copy
    | "revive" -> Revive
    | "zombie" -> Zombie
    | _ -> raise Error

let rec process_prop_action left right =
  match left with
    | Identity -> right
    | Succ -> succ right
    | Dbl -> dbl right
    | Get -> prop_get right
    | Put -> PutX
    | PutX -> right
    | S -> Sf(right)
    | Sf(f) -> Sfg(f, right)
    | Sfg(f, g) ->
      process_prop_action
	(process_prop_action f right)
	(process_prop_action g right)
    | K -> KX(right)
    | KX(x) -> x
    | Inc -> prop_inc right
    | Dec -> prop_dec right
    | Attack -> AttackI(right)
    | AttackI(i) -> AttackIJ(i, right)
    | AttackIJ(i, j) -> prop_attack i j right
    | Help -> HelpI(right)
    | HelpI(i) -> HelpIJ(i, right)
    | HelpIJ(i, j) -> prop_help i j right
    | Copy -> prop_copy right
    | Revive -> prop_revive right
    | Zombie -> ZombieI(right)
    | ZombieI(i) -> prop_zombie i right
    | Value(i) -> raise Error

let rec process_opp_action left right =
  match left with
    | Identity -> right
    | Succ -> succ right
    | Dbl -> dbl right
    | Get -> opp_get right
    | Put -> PutX
    | PutX -> right
    | S -> Sf(right)
    | Sf(f) -> Sfg(f, right)
    | Sfg(f, g) ->
      process_opp_action
	(process_opp_action f right)
	(process_opp_action g right)
    | K -> KX(right)
    | KX(x) -> x
    | Inc -> opp_inc right
    | Dec -> opp_dec right
    | Attack -> AttackI(right)
    | AttackI(i) -> AttackIJ(i, right)
    | AttackIJ(i, j) -> opp_attack i j right
    | Help -> HelpI(right)
    | HelpI(i) -> HelpIJ(i, right)
    | HelpIJ(i, j) -> opp_help i j right
    | Copy -> opp_copy right
    | Revive -> opp_revive right
    | Zombie -> ZombieI(right)
    | ZombieI(i) -> opp_zombie i right
    | Value(i) -> raise Error

let read_action () =
  let t = read_int() in
  match t with
    | 1 ->
      begin
	let card = parse_card (read_line()) in
	let slot = read_int() in
	let field, vitality = Array.get opponent slot in
	try
	  let new_field =
	    process_opp_action card field in
	  begin
	    Printf.eprintf "Opp %d (field change)" slot;
	    prerr_newline ();
	    Array.set opponent slot (new_field, vitality)
	  end
	with
	    Error ->
	      prerr_endline "Opp phase end with error"
      end
    | 2 ->
      begin
	let slot = read_int() in
	let card = parse_card (read_line()) in
	let field, vitality = Array.get opponent slot in
	try
	  let new_field =
	    process_opp_action field card in
	  begin
	    Printf.eprintf "Opp %d (field change)" slot;
	    prerr_newline ();
	    Array.set opponent slot (new_field, vitality)
	  end
	with
	    Error ->
	      prerr_endline "Opp phase end with error"
      end
    | _ -> raise Error

let lapp card slot =
  begin
    print_endline "1";
    print_endline card;
    print_int slot;
    print_newline ();
    try
      let field, vitality = Array.get proponent slot in
      let new_field =
	process_prop_action (parse_card card) field in
      begin
	(* Printf.eprintf "Prop %d (field change)" slot; *)
	(* prerr_newline (); *)
	Array.set proponent slot (new_field, vitality)
      end
    with
	Error ->
	  prerr_endline "Prop phase end with error"
  end

let rapp slot card =
  begin
    print_endline "2";
    print_int slot;
    print_newline ();
    print_endline card;
    try
      let field, vitality = Array.get proponent slot in
      let new_field =
	process_prop_action field (parse_card card) in
      begin
	(* Printf.eprintf "Prop %d (field change)" slot; *)
	(* prerr_newline (); *)
	Array.set proponent slot (new_field, vitality)
      end
    with
	Error ->
	  prerr_endline "Prop phase end with error"
  end

let rec find_alive_backward i =
  if i < 0 then
    0
  else
    let f, v = Array.get opponent i in
    if v > 0 then
      i
    else
      find_alive_backward (i - 1)

let rec find_alive_forward i =
  if i > 255 then
    255
  else
    let f, v = Array.get opponent i in
    if v > 0 then
      i
    else
      find_alive_forward (i + 1)

let find_slot_with_field x =
  let rec f i =
    if i > 255 then
      -1
    else begin
      let field, v = Array.get proponent i in
      if field = x then
	i
      else
	f (i + 1)
    end in
  f 0

let find_slot_with_field_except ex x =
  let rec f i =
    if i > 255 || i = ex then
      -1
    else begin
      let field, v = Array.get proponent i in
      if field = x then
	i
      else
	f (i + 1)
    end in
  f 0

let find_slot_with_field_value_lt x =
  let rec f i =
    if i > 255 then
      (-1, -1)
    else begin
      let field, v = Array.get proponent i in
      match field with
	| Value(y) -> begin
	  if y < x then
	    (i, y)
	  else
	    f (i + 1)
	  end
	| _ -> f (i + 1)
    end in
  f 0

let prepare_zero  =
  let index = find_slot_with_field Identity in
  if index != -1 then
    rapp index "zero"
  else begin
    let index = find_slot_with_field PutX in
    if index != -1 then
      rapp index "zero"
    else
      lapp "put" 0
  end

let rec compute_shift now target =
  if now * 2 > target then
    1
  else
    2 * compute_shift (now * 2) target

let choose_succ_dbl now target =
  if now = 0 then
    "succ"
  else begin
    let mul = compute_shift now target in
    if mul = 1 then
      "succ"
    else begin
      if mul > target - mul * now then
	"dbl"
      else
	"succ"
    end
  end

let prepare_int_value target =
  let index, value = find_slot_with_field_value_lt target in
  if index != -1 then
    lapp (choose_succ_dbl value target) 0
  else begin
    prepare_zero ()
  end

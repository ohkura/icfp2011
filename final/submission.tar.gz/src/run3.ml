let compete_one healthy_slot next_action =
  let field, vitality = proponent.(1) in
    if vitality < 1 then
      set_field_to_value
        healthy_slot
        1
        (fun _ -> lapp "revive" healthy_slot)
    else
      next_action ()
;;

let rec find_good_slot start =
  if start > 255 then
    0
  else
    let field, vitality = proponent.(start) in
      if vitality > 0 then start
      else (find_good_slot (start + 1))
;;

while true do
  let reg_command = (find_good_slot 15) in
  let reg_tmp = 1 in
    (compete_one
       (find_good_slot 30)
       (fun _ -> (create_attack
                    (find_slot_with_vitality_ge 8200 20 255)
                    reg_command
                    reg_tmp)));
    read_action ()
done
